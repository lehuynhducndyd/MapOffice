import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PrismaModule } from './prisma/prisma.module';
import { MapsController } from './map/maps.controller';
import { MapsService } from './map/maps.service';

@Module({
  imports: [PrismaModule],
  controllers: [AppController, MapsController],
  providers: [AppService, MapsService],
})
export class AppModule {}
