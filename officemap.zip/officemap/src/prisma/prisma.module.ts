import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global() 
@Module({
  providers: [PrismaService],
  exports: [PrismaService], // <--- Xuất service ra để nơi khác dùng
})
export class PrismaModule { }