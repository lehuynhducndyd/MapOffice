import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateRoomDto, CreateObjectDto, UpdateObjectDto, CreateGroupDto, UpdateRoomDto, CreateProductDto } from './dto';

@Injectable()
export class MapsService {
    constructor(private prisma: PrismaService) { }

    // ==========================================
    // PHẦN 1: QUẢN LÝ PHÒNG (ROOM)
    // ==========================================

    // 1. Tạo phòng mới
    async createRoom(data: CreateRoomDto) {
        return this.prisma.room.create({ data });
    }

    // 2. Lấy danh sách tất cả các phòng
    async getAllRooms() {
        return this.prisma.room.findMany({
            orderBy: { createdAt: 'desc' }
        });
    }

    // 3. Lấy chi tiết 1 phòng (Kèm tất cả vật thể bên trong để vẽ map)
    async getRoomDetail(id: number) {
        const room = await this.prisma.room.findUnique({
            where: { id },
            include: {
                mapObjects: {
                    include: { userGroup: true, product: true, productTable: true } // Join lấy thêm màu của nhóm và thông tin sản phẩm nếu có gắn vào vật thể nào đó
        
                }
            }
        });
        if (!room) throw new NotFoundException('Không tìm thấy phòng');
        return room;
    }

    // 4. Xóa phòng (Sẽ tự xóa hết vật thể bên trong do setup Cascade)
    async deleteRoom(id: number) {
        return this.prisma.room.delete({ where: { id } });
    }

    // ==========================================
    // PHẦN 2: QUẢN LÝ NHÓM (USER GROUP)
    // ==========================================

    async createGroup(data: CreateGroupDto) {
        return this.prisma.userGroup.create({ data });
    }

    async getAllGroups() {
        return this.prisma.userGroup.findMany();
    }

    async getGroupDetail(id: number){
        const group = await this.prisma.userGroup.findUnique({
            where: { id },
            include: { mapObjects: true }
        });
        if (!group) throw new NotFoundException('Không tìm thấy nhóm');
        return group;
    }

    async updateGroup(id: number, data: Partial<CreateGroupDto>) {
        return this.prisma.userGroup.update({
            where: { id },
            data
        });
    }

    async deleteGroup(id: number) {
        return this.prisma.userGroup.delete({ where: { id } });
    }
    async updateRoom(id: number, data: Partial<UpdateRoomDto>) {
        return this.prisma.room.update({
            where: { id },
            data
        });
    }

    // ==========================================
    // PHẦN 3: QUẢN LÝ VẬT THỂ (MAP OBJECT) - QUAN TRỌNG
    // ==========================================

    // 1. Thêm vật thể vào map
    async createObject(data: CreateObjectDto) {
        return this.prisma.mapObject.create({
            data: {
                roomId: data.roomId,
                groupId: data.groupId,
                productTableId: data.productTableId,
                objectType: data.objectType,
                posX: data.posX,
                posY: data.posY,
                width: data.width ?? 50,  // Mặc định 50 nếu không truyền
                height: data.height ?? 50,
                properties: data.properties ?? {}, // Lưu JSON
                isRotated: data.isRotated ?? false,
                productId: data.productId,
            },
        });
    }

    async getAllObjects() {
        return this.prisma.mapObject.findMany();
    }

    // 2. Cập nhật vật thể (Di chuyển bàn, đổi người ngồi...)
    async updateObject(id: number, data: UpdateObjectDto) {
       
        return this.prisma.mapObject.update({
            where: { id: id}, 
            data: {
                posX: data.posX,
                posY: data.posY,
                width: data.width,
                height: data.height,
                groupId: data.groupId,
                productId: data.productId,
                productTableId: data.productTableId,
                properties: data.properties, // Update JSON mới đè lên cũ
                isRotated: data.isRotated,
            },
        });
    }

    // 3. Xóa vật thể
    async deleteObject(id: number) {
        return this.prisma.mapObject.delete({
            where: { id: id }
        });
    }


    async createProduct(data: CreateProductDto) {
        return this.prisma.product.create({
            data,
        });
    }
    async updateProduct(id: number, data: Partial<CreateProductDto>) {
        return this.prisma.product.update({
            where: { id },
            data,
        });
    }

    // Lấy danh sách tất cả sản phẩm
    async findAllProducts() {
        return this.prisma.product.findMany();
    }

    // Lấy chi tiết một sản phẩm theo ID
    async findOneProduct(id: number) {
        return this.prisma.product.findUnique({
            where: { id },
        });
    }

    // Xóa một sản phẩm theo ID
    async removeProduct(id: number) {
        return this.prisma.product.delete({
            where: { id },
        }); 
    }
}