import { Controller, Get, Post, Put, Delete, Body, Param, Patch, ParseIntPipe } from '@nestjs/common';
import { MapsService } from './maps.service';
import { CreateRoomDto, CreateObjectDto, UpdateObjectDto, CreateGroupDto, UpdateRoomDto, CreateProductDto } from './dto';

@Controller('api') // Prefix chung là /api
export class MapsController {
    constructor(private readonly mapsService: MapsService) { }

    // --- API ROOMS ---

    @Post('rooms') // Tạo phòng
    createRoom(@Body() dto: CreateRoomDto) {
        return this.mapsService.createRoom(dto);
    }

    @Get('rooms') // Lấy danh sách phòng
    getRooms() {
        return this.mapsService.getAllRooms();
    }

    @Get('rooms/:id') // Lấy chi tiết phòng (để vẽ Map)
    getRoomDetail(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.getRoomDetail(id);
    }

    @Delete('rooms/:id') // Xóa phòng
    deleteRoom(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.deleteRoom(id);
    }

    // --- API GROUPS ---

    @Post('groups')
    createGroup(@Body() dto: CreateGroupDto) {
        return this.mapsService.createGroup(dto);
    }
    @Delete('groups/:id')
    deleteGroup(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.deleteGroup(id);
    }
    @Patch('groups/:id')
    updateGroup(
        @Param('id', ParseIntPipe) id: number,
        @Body() dto: any
    ) {
        return this.mapsService.updateGroup(id, dto);
    }

    @Get('groups')
    getGroups() {
        return this.mapsService.getAllGroups();
    }

    @Get('groups/:id')
    getGroupDetail(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.getGroupDetail(id);
    }

    @Patch('rooms/:id') // Sửa thông tin phòng
    updateRoom(
        @Param('id', ParseIntPipe) id: number,
        @Body() dto: UpdateRoomDto // DTO có thể là bất kỳ object nào, tùy theo yêu cầu cập nhật
    ) {
        console.log('Updating room with ID:', id, 'with data:', dto);
        return this.mapsService.updateRoom(id, dto);
    }

    // --- API OBJECTS (Bàn, Ghế...) ---

    @Post('objects') // Thêm vật thể
    createObject(@Body() dto: CreateObjectDto) {
        return this.mapsService.createObject(dto);
    }
    @Get('objects') // Lấy danh sách vật thể
    getObjects() {
        return this.mapsService.getAllObjects();
    }

    @Patch('objects/:id') // Sửa vật thể (Di chuyển, Update JSON)
    updateObject(
        @Param('id', ParseIntPipe) id: number,
        @Body() dto: UpdateObjectDto
    ) {
        console.log('Updating object with ID:', id, 'with data:', dto);
        return this.mapsService.updateObject(id, dto);
    }

    @Delete('objects/:id') // Xóa vật thể
    deleteObject(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.deleteObject(id);
    }

    @Post('products')
    create(@Body() createProductDto: CreateProductDto) {
        return this.mapsService.createProduct(createProductDto);
    }
    
    @Get('products')
    findAll() {
        return this.mapsService.findAllProducts();
    }

    @Get('products/:id')
    findOne(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.findOneProduct(id);
    }

    @Patch('products/:id')
    updateProduct(
        @Param('id', ParseIntPipe) id: number,
        @Body() updateProductDto: Partial<CreateProductDto>
    ) {
        return this.mapsService.updateProduct(id, updateProductDto);
    }

    @Delete('products/:id')
    remove(@Param('id', ParseIntPipe) id: number) {
        return this.mapsService.removeProduct(id);
    }


}