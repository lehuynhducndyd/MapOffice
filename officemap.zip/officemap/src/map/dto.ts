// Đổi interface thành class
export class CreateRoomDto {
    name: string;
    width: number;
    height: number;
}

export class CreateGroupDto {
    name: string;
    colorCode: string;
    description?: string;
}

export class UpdateRoomDto {
    name?: string;
    width?: number;
    height?: number;
}

export class UpdateGroupDto {
    name?: string;
    colorCode?: string;
    description?: string;
}
export class CreateObjectDto {
    roomId: number;
    groupId?: number;
    productId?: number;
    productTableId?: number;
    objectType: string;
    posX: number;
    posY: number;
    width?: number;
    height?: number;
    properties?: any;
    isRotated?: boolean;
}

export class UpdateObjectDto {
    posX?: number;
    posY?: number;
    width?: number;
    height?: number;
    groupId?: number;
    productId?: number;
    productTableId?: number;
    properties?: any;
    isRotated?: boolean;
}

export class CreateProductDto {
    name: string; // Ví dụ: "Máy in Canon"
    price: number; // Ví dụ: 2500000
    type?: string; // Ví dụ: "Máy in laser đen trắng, tốc độ 20 trang/phút"
}