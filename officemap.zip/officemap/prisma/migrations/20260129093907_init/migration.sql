-- CreateTable
CREATE TABLE "room" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "width" INTEGER NOT NULL DEFAULT 1000,
    "height" INTEGER NOT NULL DEFAULT 800,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "room_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_group" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "color_code" VARCHAR(20) DEFAULT '#CCCCCC',
    "description" TEXT,

    CONSTRAINT "user_group_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "map_object" (
    "id" SERIAL NOT NULL,
    "room_id" INTEGER NOT NULL,
    "group_id" INTEGER,
    "object_type" VARCHAR(20) NOT NULL,
    "pos_x" INTEGER NOT NULL DEFAULT 0,
    "pos_y" INTEGER NOT NULL DEFAULT 0,
    "width" INTEGER NOT NULL DEFAULT 50,
    "height" INTEGER NOT NULL DEFAULT 50,
    "properties" JSONB DEFAULT '{}',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "map_object_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "map_object_room_id_idx" ON "map_object"("room_id");

-- AddForeignKey
ALTER TABLE "map_object" ADD CONSTRAINT "map_object_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "room"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "map_object" ADD CONSTRAINT "map_object_group_id_fkey" FOREIGN KEY ("group_id") REFERENCES "user_group"("id") ON DELETE SET NULL ON UPDATE CASCADE;
