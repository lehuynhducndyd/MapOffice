-- DropIndex
DROP INDEX "map_object_room_id_idx";

-- AlterTable
ALTER TABLE "map_object" ADD COLUMN     "product_table_id" INTEGER;

-- AddForeignKey
ALTER TABLE "map_object" ADD CONSTRAINT "map_object_product_table_id_fkey" FOREIGN KEY ("product_table_id") REFERENCES "product"("id") ON DELETE SET NULL ON UPDATE CASCADE;
