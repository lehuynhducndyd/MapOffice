/*
  Warnings:

  - You are about to drop the column `is_rotate` on the `map_object` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "map_object" DROP COLUMN "is_rotate",
ADD COLUMN     "is_rotated" BOOLEAN NOT NULL DEFAULT false;
