-- AlterTable
ALTER TABLE "map_object" ADD COLUMN     "is_rotate" BOOLEAN NOT NULL DEFAULT false;
